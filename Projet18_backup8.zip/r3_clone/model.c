#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include "utilitaire.h"
#include "error.h"
#include "constantes.h"
#include "robot.h"
#include "particle.h"
#include "model.h"

#define ROT_STEP 0.04
#define TRAN_STEP 0.1

static int manual_control;

static double manual_v_rot;
static double manual_v_tran;


int initial_collisions(){
	unsigned int id_a, id_b;
	particle_allow_increment();
	robot_allow_increment();
	if(robot_collision(NULL, &id_a, &id_b)){
		error_collision(ROBOT_ROBOT, id_a, id_b);
		return 0;
	}
	if(particle_collision(NULL, &id_a, &id_b)){
		error_collision(PARTICULE_PARTICULE, id_a, id_b);
		return 0;
	}
	if(cross_collision(NULL, &id_a, &id_b)){
		error_collision(ROBOT_PARTICULE, id_b, id_a);
		return 0;
	}
	return 1;
}

static int robot_collision(	double * p_dist, unsigned int * p_id_a, 
							unsigned int * p_id_b){
	int nb_robot = robot_get_nb();
	C2D a, b;
	a.rayon = R_ROBOT;
	b.rayon = R_ROBOT;
	unsigned int id_a, id_b;
	for(int i = nb_robot-1; i >= 0; i--){
		robot_get_init_i(i);
		robot_get(&(a.centre), NULL, NULL, NULL, NULL, NULL, &id_a);
		for(int j = i-1; j >= 0; j--){
			robot_get(&(b.centre), NULL, NULL, NULL, NULL, NULL, &id_b);
			if(util_collision_cercle(a, b, p_dist)){
				if(p_id_a)
					*p_id_a = id_a;
				if(p_id_b)
					*p_id_b = id_b;
				return 1;
			}
		}
	}
	return 0;
}

static int particle_collision(	double * p_dist, unsigned int * p_id_a, 
								unsigned int * p_id_b){
	int nb_particle = particle_get_nb();
	C2D a, b;
	unsigned int id_a, id_b;
	for(int i = nb_particle-1; i >= 0; i--){
		particle_get_init_i(i);
		particle_get(NULL, &a, NULL, &id_a);
		for(int j = i-1; j >= 0; j--){
			particle_get(NULL, &b, NULL, &id_b);
			if(util_collision_cercle(a, b, p_dist)){
				if(p_id_a)
					*p_id_a = id_a;
				if(p_id_b)
					*p_id_b = id_b;
				return 1;
			}
		}
	}
	return 0;
}

static int cross_collision(	double * p_dist, unsigned int * p_id_a, 
							unsigned int * p_id_b){
	int nb_particle = particle_get_nb();
	int nb_robot = robot_get_nb();
	C2D a, b;
	b.rayon = R_ROBOT;
	unsigned int id_a, id_b;
	particle_get_init_i(nb_particle-1);
	for(int i = 0; i < nb_particle; i++){
		particle_get(NULL, &a, NULL, &id_a);
		robot_get_init_i(nb_robot-1);
		for(int j = 0; j < nb_robot; j++){
			robot_get(&(b.centre), NULL, NULL, NULL, NULL, NULL, &id_b);
			if(util_collision_cercle(a, b, p_dist)){
				if(p_id_a)
					*p_id_a = id_a;
				if(p_id_b)
					*p_id_b = id_b;
				return 1;
			}
		}
	}
	return 0;
}

//verifier tout avant de corriger, puis corriger toutes les collisions
//corriger les collisions au fur et a mesure de quand on verifie
//après avoir corrigé une collision on recommence a verifier au début. 

static int single_robot_collisions(	C2D _this, double angle, double tran, double rot, 
										unsigned int u_id) {
	robot_push_last();
	int nb_robot = robot_get_nb();
	C2D other;
	C2D new_this;
	new_this.rayon = R_ROBOT;
	other.rayon = R_ROBOT;
	int collisions = 1;
	int step = 0;
	while(collisions) {
		step++;
		collisions = 0;
		new_this.centre = util_deplacement(_this.centre, angle, tran);
		unsigned int other_id;
		double dist;
		robot_block_increment();
		robot_get_init_head();
		for(int i = 0; i < nb_robot; i++) {
			robot_get(&(other.centre), NULL, NULL, NULL, NULL, NULL, &other_id);
			robot_increment();
			if(u_id != other_id) {
				if(util_collision_cercle(new_this, other, &dist)) {
					collisions = 1;
					double L = util_distance(_this.centre, other.centre);
					double n_tran;
					if(util_inner_triangle(tran, dist, L, R_ROBOT+R_ROBOT, &n_tran)) {
						tran = n_tran;
					} else {
						tran = 0;
					}	
				}
			}
		}
		int nb_particle = particle_get_nb();
		C2D part;
		unsigned int part_uid = 0;
		particle_get_init_head();
		particle_allow_increment();
		for(int i = 0; i < nb_particle; i++) {
			particle_get(NULL, &part, NULL, &part_uid);
			if(util_collision_cercle(new_this, part, &dist)) {
				collisions = 1;
				double L = util_distance(_this.centre, part.centre);
				double n_tran;
				if(util_inner_triangle(tran, dist, L, R_ROBOT+part.rayon, &n_tran)) {
					tran = n_tran;
				} else {
					tran = 0;
				}
				new_this.centre = util_deplacement(_this.centre, angle, tran);
				if(util_alignement(new_this.centre, angle, part.centre)) {
					particle_delete_u(part_uid);
				}	
			}
		}
		break; //temporaire a cause du bug relou ...
		if(step > nb_robot*nb_robot*nb_particle) {
			//printf("FATAL_ERROR\n");
			break;
		}
	}	
	robot_pop_last();
	robot_move(tran, rot);

	return 0;
}

//~ int model_collision(void) {
	//~ robot_block_increment();
	//~ particle_block_increment();
	//~ int nb_part = particle_get_nb();
	//~ int nb_robot = robot_get_nb();
	//~ C2D this;
	//~ this.rayon = R_ROBOT;
	//~ C2D rob;
	//~ rob.rayon = R_ROBOT;
	//~ C2D part;
	//~ S2D this_prev;
	//~ unsigned int rob_id;
	//~ robot_get_init_head();
	//~ for(int i = 0; i < nb_robot; i++) {
		//~ robot_get(&(this.centre), &this_prev, NULL, NULL, NULL, &rob_id, NULL);
		//~ robot_push_last();
		//~ robot_increment();
		//~ for(int i = rob_id-1; i >= 0; i--) {
			//~ double dist;
			//~ unsigned id;
			//~ S2D rob_prev;
			//~ robot_get(&(rob.centre), &rob_prev, NULL, NULL, NULL, &id, NULL);
			//~ if(util_collision_cercle(this, rob, &dist)) {
				
				//~ double n_tran;
				//~ double tran_this;
				//~ double tran_rob;
				//~ double L;
				//~ L = util_distance(this_prev, rob.centre);
				//~ tran_this = util_distance(this_prev, this.centre);
				//~ if(util_inner_triangle(tran_this, dist, L, R_ROBOT+R_ROBOT, &n_tran)) {
					//~ tran_this -= n_tran;
				//~ }
				//~ L = util_distance(rob_prev, this.centre);
				//~ tran_rob = util_distance(rob_prev, rob.centre);
				//~ if(util_inner_triangle(tran_rob, dist, L, R_ROBOT+R_ROBOT, &n_tran)) {
					//~ tran_rob -= n_tran;
				//~ }
				//~ if(tran_rob > tran_this) {
					//~ robot_pop_last();
					//~ robot_correct(-tran_this, 0);
				//~ } else {
					//~ robot_correct(-tran_rob, 0);
					//~ robot_pop_last();
				//~ }
				//~ return 0;
			//~ }
			//~ robot_increment();
		//~ }
		//~ robot_pop_last();
		//~ particle_get_init_head();
		//~ for(int i = 0; i < nb_part; i++) {
			//~ double dist;
			//~ unsigned id;
			//~ particle_get(NULL, &part, &id, NULL);
			//~ if(util_collision_cercle(this, part, &dist)) {
				//~ double L = util_distance(this_prev, part.centre);
				//~ double tran = util_distance(this_prev, this.centre);
				//~ double n_tran;
				//~ if(util_inner_triangle(tran, dist, L, R_ROBOT+part.rayon, &n_tran)) {
					//~ tran -= n_tran;
				//~ }
				//~ robot_move(-tran, 0);
				//~ return 0;
			//~ }
			//~ particle_increment();
		//~ }
		//~ robot_increment();
	//~ }
	//~ return 1;
//~ }

static void move(void) {
	C2D c_robot;
	S2D targ;
	unsigned int id;
	double c_angle;
	double v_tran = 0, v_rot = 0;
	double delta_angle;
	int selected;
	c_robot.rayon = R_ROBOT;
	robot_get(&(c_robot.centre), NULL, &targ, &c_angle, &selected, NULL, &id);
	if(!selected) {
		if(util_ecart_angle(c_robot.centre, c_angle, targ, &delta_angle)) {
			if(fabs(delta_angle) < M_PI/3.0) {
				if(VTRAN_MAX*DELTA_VTRAN > util_distance(c_robot.centre, targ)) {
					v_tran = util_distance(c_robot.centre, targ);
				} else {
					v_tran = VTRAN_MAX;
				}
			}
			if(fabs(delta_angle) < VROT_MAX*DELTA_VROT) {
				v_rot = delta_angle;
			} else {
				if(delta_angle < 0) {
					v_rot = -VROT_MAX;
				} else {
					v_rot = VROT_MAX;
				}
			}
		}
	} else {
		v_rot = manual_v_rot;
		v_tran = manual_v_tran;
	}
	single_robot_collisions(c_robot, c_angle, v_tran*DELTA_VTRAN, v_rot*DELTA_VROT, id); 
}

void model_update(void) {
	int nb_robot = robot_get_nb();
	if(particle_get_event()) {
		model_select_targets();
	}
	model_handle_blocked();
	robot_get_init_head();
	robot_block_increment();
	for(int i = 0; i < nb_robot; i++) {
		move();
		robot_increment();
	}
	particle_decomposition();
	//~ while(!model_collision());
}

//~ void model_select_targets(void) {
	//~ particle_untarget_all();
	//~ int nb_robot = robot_get_nb();
	//~ int nb_part = particle_get_nb();
	//~ robot_block_increment();
	//~ particle_block_increment();
	//~ robot_get_init_head();
	//~ S2D rob;
	//~ C2D part;
	//~ S2D closest;
	//~ unsigned int i_id;
	//~ unsigned int c_i_id;
	//~ for(int i = 0; i < nb_robot; i++) {
		//~ double c_dist = 2*DMAX;
		//~ particle_get_init_head();
		//~ robot_get(&rob, NULL, NULL, NULL, NULL, NULL);
		//~ for(int j = 0; j < nb_part; j++) {
			//~ particle_get(NULL, &part, &i_id, NULL);
			//~ double dist = util_distance(rob, part.centre);
			//~ if(dist < c_dist && !particle_targeted()) {
				//~ c_dist = dist;
				//~ closest = part.centre;
				//~ c_i_id = i_id;
			//~ }
			//~ particle_increment();
		//~ }
		//~ robot_set_target(closest);
		//~ particle_get_init_i(c_i_id);
		//~ particle_target();
		//~ robot_increment();
	//~ }
//~ }

void model_select_targets(void) {
	int nb_robot = robot_get_nb();
	robot_block_increment();
	particle_allow_increment();
	particle_get_init_head();
	robot_get_init_head();
	C2D part;
	for(int i = 0; i < nb_robot; i++) {
		if(!robot_get_blocked()) {
			particle_get(NULL, &part, NULL, NULL);
			robot_set_target(part.centre);
		}
		robot_increment();
	}
}

void model_handle_blocked(void) {
	robot_block_increment();
	particle_block_increment();
	robot_get_init_head();
	int nb_robots = robot_get_nb();
	int nb_part = particle_get_nb();
	for(int i = 0; i < nb_robots; i++) {
		if(robot_get_blocked()) {
			unsigned id;
			S2D rob;
			C2D part;
			robot_get(&rob, NULL, NULL, NULL, NULL, &id, NULL);
			//printf("%u blocked ! \n", id);
			particle_get_init_head();
			S2D closest;
			double closest_d = 2*DMAX; // a "very big" distance
			for(int i = 0; i < nb_part; i++) {
				particle_get(NULL, &part, NULL, NULL);
				double d = util_distance(rob, part.centre);
				if(d < closest_d) {
					closest_d = d;
					closest = part.centre;
				}
				robot_set_target(closest);
				particle_increment();
			}
		}
		robot_increment();
	}
}

void model_set_manual_control(void) {
	manual_control = 1;
}

void model_set_auto_control(void){
	manual_control = 0;
	robot_deselect_all();
}

int model_get_control_mode(void){
	return manual_control;
}

void model_select(S2D point) {
	if(manual_control) {
		robot_deselect_all();
		C2D rob;
		int selected;
		rob.rayon = R_ROBOT;
		int nb_robot = robot_get_nb();
		robot_push_last();
		robot_get_init_head();
		robot_block_increment();
		for(int i = 0; i < nb_robot; i++) {
			robot_get(&(rob.centre), NULL, NULL, NULL, &selected, NULL, NULL);
			if(util_point_dans_cercle(point, rob)) {
				if(selected) {
					robot_deselect();
				} else {
					robot_select();
				}
				break;
			}
			robot_increment();
		}
		robot_allow_increment();
		robot_pop_last();
	}
}

void model_man_for(void){
	if(manual_control) {
		if(manual_v_tran <= VTRAN_MAX)
			manual_v_tran += TRAN_STEP;
	}
}

void model_man_back(void){
	if(manual_control) {
		if(manual_v_tran >= -VTRAN_MAX)
			manual_v_tran -= TRAN_STEP;
	}
}

void model_man_left(void){
	if(manual_control) {
		if(manual_v_rot <= VROT_MAX)
			manual_v_rot += ROT_STEP;
	}
}

void model_man_right(void){
	if(manual_control) {
		if(manual_v_rot >= -VROT_MAX)
			manual_v_rot -= ROT_STEP;
	}
}

void model_reset_man(void) {
	manual_v_rot = 0;
	manual_v_tran = 0;
}

double model_get_man_vrot(void) {
	return manual_v_rot;
}

double model_get_man_vtran(void) {
	return manual_v_tran;
}



