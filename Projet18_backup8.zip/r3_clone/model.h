#ifndef MODEL_H
#define MODEL_H

/**
 * \brief	checks the collisions and prints the associated errors
 */
int initial_collisions(void);

/**
 * \brief	checks the collisions between all the robots, returns 1 if there is at
 * 			least one collision, the arguments stored in pointers are for the first
 * 			collision detected
 * \param	p_dist		pointer for the distance between the two colliding robots
 * \param	p_id_a		pointer for the uniq id of one robot colliding
 * \param	p_id_b		pointer for the uniq id of the other robot colliding
 */
static int robot_collision(	double * p_dist, unsigned int * p_id_a,
							unsigned int * p_id_b);


/**
 * \brief	checks the collisions between all the particles, returns 1 if there is at
 * 			least one collision, the arguments stored in pointers are for the first
 * 			collision detected
 * \param	p_dist		pointer for the distance between the two colliding particles
 * \param	p_id_a		pointer for the uniq id of one particle colliding
 * \param	p_id_b		pointer for the uniq id of the other particle colliding
 */
static int particle_collision(	double * p_dist, unsigned int * p_id_a, 
								unsigned int * p_id_b);


/**
 * \brief	checks the collision between all the robots and all the particles,
 * 			returns 1 if there is at least one collision the arguments stored in 
 * 			pointers are for the first collision detected
 * \param	p_dist		pointer for the distance between the two colliding objects
 * \param	p_id_a		pointer for the uniq id of the particle colliding
 * \param	p_id_b		pointer for the uniq id of the robot colliding
 */
static int cross_collision(	double * p_dist, unsigned int * p_id_a, 
							unsigned int * p_id_b);
							
static int single_robot_collisions( C2D _this, double angle, double tran, double rot, 
										unsigned int u_id);					
static int model_collision(void);

void model_update(void);
void model_select(S2D point);

void model_select_targets(void);
void model_handle_blocked(void);

void model_set_manual_control(void);
void model_set_auto_control(void);
int model_get_control_mode(void);
void model_man_for(void);
void model_man_back(void);
void model_man_left(void);
void model_man_right(void);
double model_get_man_vtran(void);
double model_get_man_vrot(void);
void model_reset_man(void);

#endif
