#ifndef ROBOT_H
#define ROBOT_H

#include "utilitaire.h"

/*
 * every robot has the following attributes:
 * body			position and radius
 * angle		orientation
 * u_id			unique identifier
 * i_id			iteration identifier
 * next			link to the previous robot
 * */

typedef struct robot ROBOT;

/**
 * \brief	delete one robot selected by its unique ID
 * \param	id		the unique ID of the robot to delete
 */
int robot_delete_u(unsigned int id);

/**
 * \brief	delete one robot selected by its iteration ID
 * \param	id		the iteration ID of the robot to delete
 */
int robot_delete_i(unsigned int id);

/**
 * \brief	delete every robot
 */
void robot_delete_all(void);

/**
 * \brief	print the attributes of every robot
 */
void robot_print(void);

/**
 * \brief	initialize the get function to a robot (iter ID)
 * \param	id		the iteration ID of the next robot to get
 */
void robot_get_init_i(unsigned int id);

/**
 * \brief	initialize the get function to a robot (uniq ID)
 * \param	id		the unique ID of the next robot to get
 */
void robot_get_init_u(unsigned int id);

void robot_get_init_head(void);

void robot_set_target(S2D target);
void robot_randomize_targets(void); 

void robot_get(	S2D * pos, S2D * target, double * angle, int * selected, unsigned int * i_id, 
				unsigned int * u_id);

/**
 * \brief	create a robot and returns its uniq ID
 * \param	x		x position of the robot
 * \param	y		y position of the robot
 * \param	angle	orientation of the robot
 */
unsigned int robot_create(double x, double y, double a);

void robot_push_last(void);
void robot_pop_last(void);
void robot_allow_increment(void);
void robot_increment(void);
void robot_block_increment(void);
void robot_move(double dist, double angle);
void robot_set_all_targets(S2D target);

void robot_select(void);
void robot_deselect(void);
void robot_deselect_all(void);

/**
 * \brief	returns the number of robots
 */
int robot_get_nb(void);


#endif
